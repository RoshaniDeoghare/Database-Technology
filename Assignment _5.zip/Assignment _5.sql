create database Assignment_5;
use Assignment_5;

Create table EMP ( EMPNO numeric(4) not null,
				   ENAME varchar(30) not null, 
                   JOB varchar(10), 
                   MGR numeric(4), 
                   HIREDATE date, 
                   SAL numeric(7,2), 
                   DEPTNO numeric(2) ); 
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1000,  'Manish' , 'SALESMAN', 1003,  '2020-02-18', 600,  30) ;
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1001,  'Manoj' , 'SALESMAN', 1003,  '2018-02-18', 600,  30) ;
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1002 , 'Ashish', 'SALESMAN',1003 , '2013-02-18',  750,  30 );
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1004,  'Rekha', 'ANALYST', 1006 , '2001-02-18', 3000,  10);
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1005 , 'Sachin', 'ANALYST', 1006 ,  '2019-02-18', 3000, 10 );
Insert into EMP (EMPNO ,ENAME, JOB, MGR, HIREDATE, SAL, DEPTNO ) values(1006,  'Pooja',  'MANAGER', null, '2000-02-18' ,6000, 10 );
select * from EMP; 
update emp set sal = 600 where deptno = 30;
update emp set sal = 750 where empno = 1002;
update emp set sal = 3000 where empno = 1004;

Create table Dept (dno numeric(4) not null, 
				   dname varchar(10) not null,
                   area varchar(30));
Insert into Dept(dno,dname,area) values(10,'Store','Mumbai');
Insert into Dept(dno,dname,area) values(20,'Purchase','Mumbai');
Insert into Dept(dno,dname,area) values(30,'Store', 'Delhi');
Insert into Dept(dno,dname,area) values(40,'Marketing','Pune');
Insert into Dept(dno,dname,area) values(50,'Finance','Delhi');
Insert into Dept(dno,dname,area) values(60,'Accounts','Mumbai');
select * from Dept;

/* 1.	Write a Procedure that accepts values of two non-zero numbers using IN parameter and perform addition, subtraction, multiplication, division and print.*/

delimiter ##

create procedure All_Opearation(IN num1 int, IN num2 int)
BEGIN
declare Sum, Difference, Product, Division int;

set Sum = num1 + num2;
set Difference = num1 - num2;
set Product = num1 * num2;
set Division = num1 / num2 ;

select  Sum, Difference, Product, Division;
END ##
call All_Opearation(20,4);

/* 2.	Write a Procedure to print the string in REVERSE order. Take the input using IN parameter. (Ex .Database , o/p :esabatad)*/

delimiter $$
create procedure Reverse_String()
BEGIN

declare STR_NAME varchar(50) ;
set STR_NAME = "Database" ;
select REVERSE(STR_NAME);
 
 END $$
 
 CALL Reverse_String() ;
 
drop procedure Reverse_String_IN;
delimiter &&
create procedure Reverse_String_IN(INOUT Str_name varchar(50))
BEGIN
select REVERSE(Str_Name) into Str_Name ;
 END &&
 
 set @X = "Roshani" ;
 call Reverse_String_IN(@X) ;
 select @X ;
 
 
 /* 3.	Write a Procedure to display top 5 employee based on highest salary and display employee number, employee name and salary.*/
 
 drop procedure Display_top_emp;
 delimiter //
 create procedure Display_top_emp()
 BEGIN
 select Empno, Ename, sal from EMP order by sal desc limit 5;
 END //
 
 call Display_top_emp();
 
 
 /* 5.	Write a Procedure to add a department row in the DEPT table with the following values for columns */
 
 delimiter &&
 create  procedure Table_dept()
 BEGIN
 
 insert into dept values(60,'Education','Pune');
 select * from dept;
 END &&
 
 call Table_dept();
 
 /* 6.	Write a program that declares an integer variable called num, assigns a value to it and print, the value of the variable itself, its square, and its cube.*/

delimiter ##
create procedure Square_Cube(IN num int)
BEGIN

declare Square, Cubes int;
set Square = num * num;
set Cubes = num * num * num ;

select num, Square, Cubes;
END ##

call Square_Cube(12);

/* 7.	Write a program that declares an integer variable assign a value to it and display it using OUT parameter.*/

delimiter //
create procedure Declare_integer_OUT(OUT var int)
BEGIN
set @var = 45;
select @var;
END //

call Declare_integer_OUT(@var);

delimiter //
create procedure Declare_integer(OUT Num1 int)
BEGIN
declare Num int;
set Num = 12;
select Num into Num1;
END //

call Declare_integer(@Num1);
select @Num1;

/* 8.	Write a program that demonstrates the usage of IN and OUT parameters. */

delimiter $$
create procedure my_sqrt(IN num1 int , Out num2 int)
BEGIN
set num2 = sqrt(num1);
END $$

call my_sqrt(225, @num2);
select @num2;